(function(){
	
var gameid;

//获取当前js文件的文件名
var scripts = document.getElementsByTagName('script');
// 获取现在已经加载的所有script
var lastScript = scripts[scripts.length-1];
// 获取最近一个加载的script，即这个js本身
var scriptName = lastScript.src;
// 获取此js的路径
var start=scriptName.lastIndexOf("/")+1;
var end=scriptName.lastIndexOf(".");
var animName=scriptName.slice(start,end);

for(var i=0;i<animateControlInfo.length;i++){
	if(animateControlInfo[i].ctrlBar==animName){
		gameid=i;
		break;
	}
}

var close=true;
for(var j=0;j<animateControlInfo.length;j++){
	$(animateControlInfo[gameid].btn).click(function(){
		if(close){
			updateHandler();
		}
		close=!close;
	})
}	


var canvas, stage, root;
var shapeData=[];
var selectedShapes=[];
var initColor="#5F55D9";
var selectedColor="#D81803";
var newShapes=[];


init();

function init() {
	canvas = document.getElementById(animateControlInfo[gameid].canvasId);
	var donghua="new lib."+animateControlInfo[gameid].name+"()"
	root = eval(donghua);

	stage = new createjs.Stage(canvas);
	stage.addChild(root);
	stage.update();
	
	createjs.Ticker.setFPS(lib.properties.fps);
	createjs.Ticker.addEventListener("tick", stage);	
	gameInit();
}


function updateHandler(){
	for(var i=0;i<newShapes.length;i++){
		root.removeChild(newShapes[i]);
	}
	newShapes=[];
	while(selectedShapes.length>0){
		var shape=selectedShapes.pop();
		shape.selected=false;
		createjsExtend.drawPolygon(shape,shape.pointData,3,"#ffffff",initColor);
	}
}

function gameInit(){
	setShapeData();
	var shapes=createShapes(shapeData);
	addEventTo(shapes);
	addEventToBtn();
}

function setShapeData(){
	var shapeData1=[root.p1,root.p2,root.p3];
	var shapeData2=[root.p1,root.p3,root.p4];
	var shapeData3=[root.p1,root.p4,root.p5];
	var shapeData4=[root.p1,root.p5,root.p6];
	var shapeData5=[root.p2,root.p3,root.p8,root.p7];
	var shapeData6=[root.p3,root.p4,root.p9,root.p8];
	var shapeData7=[root.p4,root.p5,root.p10,root.p9];
	var shapeData8=[root.p5,root.p6,root.p11,root.p10];
	shapeData=[shapeData1,shapeData2,shapeData3,shapeData4,shapeData5,shapeData6,shapeData7,shapeData8];
}

function createShapes(shapeData){
	var shapes=[];
	for(var i=0;i<shapeData.length;i++){
		var shape=new createjs.Shape();
		shape.pointData=shapeData[i];
		shape.selected=false;
		shape.pos=shapeData[i][0];//图形的注册点位置
		createjsExtend.drawPolygon(shape,shape.pointData,3,"#ffffff",initColor);
		root.addChild(shape);
		shapes.push(shape);
	}	
	return shapes;
}

function addEventTo(shapes){
	for(var i=0;i<shapes.length;i++){
		shapes[i].addEventListener("mousedown",function(e){
			var shape=e.currentTarget;
			if(shape.selected){
				createAndDragNewShape();	
				for(var i=0;i<selectedShapes.length;i++){
					createjsExtend.drawPolygon(selectedShapes[i],selectedShapes[i].pointData,3,"#ffffff",initColor);
					selectedShapes[i].selected=false;
				}
				selectedShapes=[];
			}else{
				shape.selected=true;
				arrayUtils.addSingleEleToArray(selectedShapes,shape);
				createjsExtend.drawPolygon(shape,shape.pointData,3,"#ffffff",selectedColor);
			}
		})
	}
}

function addEventToBtn(){
	root.undoBtn.addEventListener("click",function(){
		var shape=selectedShapes.pop();
		shape.selected=false;
		createjsExtend.drawPolygon(shape,shape.pointData,3,"#ffffff",initColor);
	})
	
	root.updateBtn.addEventListener("click",function(){
		updateHandler();
	})
}

function createAndDragNewShape(){
	
	var points=getPointDataBy(selectedShapes);
	var convexPoints=getConvexHull(points);
	//如果顶点数不是3个或者所选图形面积之和与3个顶点形成的图形面积不同，说明所选不是三角形
	if(convexPoints.length!=3||Math.abs(getPolygonArea(convexPoints)-getShapesArea(selectedShapes))>40){
		return;
	}
	
	var newShape=new createjs.MovieClip();
	for(var i=0;i<selectedShapes.length;i++){
		newShape.addChild(selectedShapes[i].clone(true,true));
	}
	newShape.pos=convexPoints[0];
	/*var newShape=new createjs.Shape();
	createjsExtend.drawPolygon(newShape,convexPoints,3,"#ffffff","#FFF900");*/
	root.addChild(newShape);
	newShapes.push(newShape);
	newShape.addDragAction(new createjs.Rectangle(-600,-600,1500,1500),stage,false,true);
	newShape.moveHandler=function(){
		var point=this.localToGlobal(this.pos.x,this.pos.y);
		if(createjsExtend.getDistance(point,root.recycleBin)<100){
			root.recycleBin.gotoAndStop(1);
			this.alpha=0.5;
		}else{
			root.recycleBin.gotoAndStop(0);
			this.alpha=1;
		}
	}
	newShape.mouseupHandler=function(){
		var point=this.localToGlobal(this.pos.x,this.pos.y);
		if(createjsExtend.getDistance(point,root.recycleBin)<100){
			root.removeChild(this);
			newShapes.splice(newShapes.indexOf(this),1);
			root.recycleBin.gotoAndStop(0);
		}
	}
}

//取得所有图形顶点的坐标
function getPointDataBy(selectedShapes){
	var pointData=[];
	for(var i=0;i<selectedShapes.length;i++){
		for(var j=0;j<selectedShapes[i].pointData.length;j++){
			if(pointData.indexOf(selectedShapes[i].pointData[j])==-1){
				pointData.push(selectedShapes[i].pointData[j]);
			}
		}
	}
	return pointData;
}

//求点的凸包
function getConvexHull(points){
	var convexPoints=[];
	var startPoint=getStartPoint(points);
	points.splice(points.indexOf(startPoint),1);
	points.sort(compare);
	convexPoints.push(startPoint);
	convexPoints.push(points[0]);
	
	for(i=1;i<points.length;i++){
		var vector1={	x:convexPoints[convexPoints.length-1].x-convexPoints[convexPoints.length-2].x,
						y:convexPoints[convexPoints.length-1].y-convexPoints[convexPoints.length-2].y};
						
		var vector2={	x:points[i].x-convexPoints[convexPoints.length-1].x,
						y:points[i].y-convexPoints[convexPoints.length-1].y};
		
		while(getCross(vector1,vector2)<0){
			convexPoints.pop();
			vector1={	x:convexPoints[convexPoints.length-1].x-convexPoints[convexPoints.length-2].x,
						y:convexPoints[convexPoints.length-1].y-convexPoints[convexPoints.length-2].y};
			vector2={	x:points[i].x-convexPoints[convexPoints.length-1].x,
						y:points[i].y-convexPoints[convexPoints.length-1].y};
		}
		convexPoints.push(points[i]);
	}
	
	//去掉一条线上中间的点,留下顶点
	convexPoints.push(startPoint);
	deletePointIndexs=[];
	for(i=0;i<convexPoints.length-2;i++){
		var vector1={x:convexPoints[i+1].x-convexPoints[i].x,y:convexPoints[i+1].y-convexPoints[i].y}
		var vector2={x:convexPoints[i+2].x-convexPoints[i+1].x,y:convexPoints[i+2].y-convexPoints[i+1].y}
		var angle=getAngle(vector1,vector2);
		if(Math.abs(angle)<Math.PI/90){
			deletePointIndexs.push(i+1);
		};
	}
	if(deletePointIndexs.length>0){
		for(i=deletePointIndexs.length-1;i>=0;i--){
			convexPoints.splice(deletePointIndexs[i],1);
		}
	}
	convexPoints.pop();
	
	return convexPoints;
	
	//各点按极坐标的角度排序
	function compare(value1,value2){
		var value1Angle=getPolarAngle(startPoint,value1);
		var value2Angle=getPolarAngle(startPoint,value2);
		if(value1Angle<value2Angle){
			return -1;
		}else if (value1Angle>value2Angle){
			return 1;
		}else{
			return 0;
		}
	}
	
	//选出y轴最小的点startPoint
	function getStartPoint(points){
		var startPoint=points[0];
		for(var i=1;i<points.length;i++){
			if(points[i].y<startPoint.y){
				startPoint=points[i];
			}else if(points[i].y==startPoint.y){
				if(points[i].x<startPoint.x){
					startPoint=points[i];
				}
			}
		}
		return startPoint
	}
}
//得到多个图形的面积和
function getShapesArea(shapes){
	var area=0;
	for(var i=0;i<shapes.length;i++){
		area+=getPolygonArea(shapes[i].pointData);
	}
	return area;
}
//根据图形各顶点坐标求图形面积,思路：将多边形分解为多个三角形，利用叉积计算三角形面积
function getPolygonArea(pointData){
	var area=0;
	var startPoint=pointData[0];
	for(var i=1;i<pointData.length-1;i++){
		var vector1={x:pointData[i].x-startPoint.x,y:pointData[i].y-startPoint.y};
		var vector2={x:pointData[i+1].x-pointData[i].x,y:pointData[i+1].y-pointData[i].y};
		area+=Math.abs(getCross(vector1,vector2))/2;
	}
	return area;
}

//得到向量极坐标的角度，p1和p2为向量的起点和终点
function getPolarAngle(p1,p2){
	return Math.atan2(p2.y-p1.y,p2.x-p1.x);
}

//求两个向量的叉积
function getCross(vector1,vector2){
	return vector1.x*vector2.y-vector2.x*vector1.y;
}

//求两向量的夹角
function getAngle(vector1,vector2){
	return Math.acos(getDot(vector1,vector2)/(getLengthOfVector(vector1)*getLengthOfVector(vector2)));
}

//求向量的长度
function getLengthOfVector(vector){
	return Math.sqrt(vector.x*vector.x+vector.y*vector.y);
}

//求两向量的点积
function getDot(vector1,vector2){
	return vector1.x*vector2.x+vector1.y*vector2.y;
}



})();
