var animateControlInfo=[
							{btn:"#demon_BtnA",name:"donghua1",ctrlBar:"game1",canvasId:"canvas1"},
							{btn:"#demon_BtnB",name:"donghua2",ctrlBar:"game2",canvasId:"canvas2"},
							{btn:"#demon_BtnC",name:"donghua3",ctrlBar:"game3",canvasId:"canvas3"},
							{btn:"#demon_BtnD",name:"donghua4",ctrlBar:"game4",canvasId:"canvas4"},
						]