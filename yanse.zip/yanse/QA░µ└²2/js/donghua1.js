(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 1024,
	height: 768,
	fps: 24,
	color: "#000033",
	manifest: []
};



// symbols:



(lib.撤销 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai8BUIAAhPIgKAHIgEAEIAAA5QgCAXgegKQgIgDACgJQACgIAIACQAIACAAgFIAAgpIgCABIgFACQgJAEgFgJQgCgJAJgGIAHgFIAHgCIAAgkIgIAAQgKAAAAgKQAAgJAKgBIAIAAIAAgXQAAgKAKgBQAJAAABAKIAAAYIAEAAQAJABABAJQgBAKgJAAIgEAAIAAAcQALgFADAJQAAgHAQAAIAmAAQAKAAABAJQANgZACg2QABgJAKgBQAKACAAAJIgBAOIAYAAQAHAAACAKQAAAKgHABIgCAAQABA5gMAfIAOAYQAFAGABAEQABAPgOgBQgGAAgOgZQgMAUgLAGQgNAEAAgMQgFAKgZgGQgIgCABgJQADgIAIABQAKADgCgHIAAgKIgaAAIAAAcQAAAKgKAAQgJgBgBgJgAh6BLQAOgNAJgTIgKghQgFAGgIgGgAioApIAaAAIAAgKIgaAAgAhbgnQgCANgCAIIAIAhQADgVAAgnIgGAAIgBAGgAioAIIAAAHIAaAAIAAgHQAAgBAAgBQAAAAAAAAQgBgBAAAAQgBAAAAAAIgVAAQgBAAAAAAQgBAAAAABQAAAAgBAAQAAABAAABgAByBTIAAhoQgBgQAQAAIAkAAIAAgvQAAgHALAAQALABAAAHIAAAuIApAAQAMAAABAOIAABbQADAagvgHQgMgDgCgHQgCgKALgBIALAAQARADgBgHIAAgMIhTAAIAAAgQgGAJgGAAQgFAAgFgIgACJAdIBSAAIAAgNIhSAAgACJgNIAAAKIBSAAIAAgJQAAgDgDgBIhMAAQgBAAAAAAQgBAAAAABQgBAAAAABQAAAAAAABgABKBYQgJgEAEgLIAIgaIAKgcQADgKALACQAIAEgBALQgLAigHAUQgFAJgHAAIgEgBgABYgDIgMgLIgHgHQgHgIAGgHQAHgHAIAGIAUATQAGAIgGAIQgDACgEAAQgEAAgEgDgAiDgUQgQACgdAAQgTAAAGgQQAEgIAJgLIgHAAQgKgBAAgJQABgJAJgBIAWAAQgEgIAAgEQAAgGAKgCQAKgBAJAVIAPAAQAJABABAJQgBAJgJABIghAAIgEAFQgIAJgBADQAAABAAAAQABAAAAABQAAAAAAAAQABAAAAAAQAOAAAMgCQgCgDAAgCQgCgGAHgDQAFgBAFAFQAIAIACAKQAAALgJABQgEgCgCgCgADSgoQgJgGAHgMIALgRIAGgHQAGgHAJAFQAHAGgEAJQgFAJgKAOQgGAHgHAAIgFgBgACBguQgJgJgIgNQgGgIAIgHQAIgGAIAIIAQAVQAFALgHAGQgDACgDAAQgFAAgEgFgABag3QgHgGgIgKIgCgCQgGgHAHgHQAHgGAIAGQADAFADACIAJAKQAGAJgGAHQgDADgDAAQgEAAgEgEg");
	this.shape.setTransform(33.6,13.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2290B1").s().rr(-30.6,-12,61.2,24,4.4);
	this.shape_1.setTransform(34.5,13.5,1.126,1.126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,27.1);


(lib.垃圾桶 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A7AFF").s().p("AALCTIA1hfIAAAcICMAAIg+BmIhOAAIAAAtgAiYC7Ig3hnIC+AAIAABngAjcA+IgTg9IAdgvIgdgPIBpgDIArBVIgagPIgfA4gACIA5IgshcIBXg5IA9BvIgXAmgAimh7IA+hnIA2AAIAiA0Ig7BqgAAwhvIhGhzIB7AAIAiA7IAZgQIguBcIhyALg");
	this.shape.setTransform(1.3,81.9,1,1,0,0,0,-0.1,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#454F5F","#C4D5FF","#4A4D5F"],[0,0.729,1],48,-32.8,-46.9,-32.8).s().p("AkMA5QhugUgBgbIAAhVQABAbBuATQBwATCcAAIANAAQBCAAA8gEQBHgFA7gKQBrgSAFgaIAABWQgFAZhrATQhwATidAAQicAAhwgTg");
	this.shape_1.setTransform(0.2,131.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#95A4C4").s().p("AAAAvQicAAhwgTQhugTgBgZIAAgBQgBgHAKgHQAJgIAUgHIAFAaIAAABIABAEQABAEAGAEIAEADQAXAKBAAKQBjAPCKAAIATAAQBEgBA5gEQAzgEAsgGQBHgLAUgMQAGgEACgEIAAgEIAAAAIAFgbQATAHAKAIQAIAGABAHIAAADQgFAYhrATQg7AKhHAFQg8AEhCAAIgNAAg");
	this.shape_2.setTransform(0.2,125.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(174,203,243,0.6)").s().p("AkSG0IgFgDQgFgEgCgEIgBgFIgEgaIiftPQAkANB9ARQB8ARDWAAQByAABYgEQAhgFAdABQChAEgaDAQgFAlgNAtQg5DmiXDLQh5CdjXAAQhKAAhWgSg");
	this.shape_3.setTransform(-4.8,81.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(97,127,168,0.6)").s().p("AAAAcQjYgBh9gPQh8gNgkgNIgBgBIgCgNIADACQAkANBgALQCaAQDXAAQDYAACYgQQBXgJAmgMIAMgFIgDANIgOAFQgqAKhpANQhAAIhWAEQhEAEhTAAIgogBg");
	this.shape_4.setTransform(0.1,36);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#454F5F","#C4D5FF","#4A4D5F"],[0,0.827,1],48.1,66.4,-46.8,66.4).s().p("AlwAiQhhgLgjgNIgEgCQgPgGgCgGIAAgtQACAIATAHIAJADQAlAMBWAKQCZAPDXAAQDYAACZgPQBZgKAmgNQAZgJABgKIAAAuQAAAGgRAHIgMAFQgmAMhWAJQiZASjYAAQjXAAiZgSg");
	this.shape_5.setTransform(0.1,32.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(130,161,203,0.6)").s().p("AAAIJQiJAAhjgPQhAgLgXgLQFNBICjjUQCXjKA6jmQAMgtAFglQAajAihgEQgcgBgiAEQhXAFhzAAQjWgBh8gQQh8gRglgNIgDgQIABABQAkANB8APQB9APDYABQBqABBVgEQBWgEBAgIQBpgNAqgNIAOgEIieNfIgFAbIAAADQgCAFgGADQgUAOhHAMQgsAGgzADQg5AFhEABIgUAAgAlenJQhcgKgigMIgFgCIAFgCQAigMBcgJQCTgQDMABQDQgBCSAQQBjAKAgANQggAOhjAKQiSAPjQAAQjMAAiTgPg");
	this.shape_6.setTransform(0.1,76.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#454F5F","#C4D5FF","#4A4D5F"],[0,0.235,1],47.9,73.5,-47,73.5).s().p("AnxAUIgBgBQAAgIAUgHQAigKBcgKQCTgPDNAAQDPAACSAPQCRAQABASQAAAHgPAHQgggOhjgKQiSgNjPAAQjNAAiTANQhcAJgiANIgFACQgOgGAAgGg");
	this.shape_7.setTransform(0.3,25.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B3C1DE").s().p("AlwApQhVgJgmgNIgJgDQgTgHgBgIIgBgBQAAgIAVgIQAkgOBggLQCZgQDXAAQDYAACZAQQCYASABAXIAAAAQgBAKgZAIQgmANhZAKQiZASjYAAQjXAAiZgSgAldgiQhdAKghAMQgVAHAAAGIABABQABAGANAGIAGACQAhAMBdAJQCSAPDNAAQDPAACSgPQBkgKAggNQAOgHAAgHQAAgSiSgQQiSgPjPAAQjNAAiSAPg");
	this.shape_8.setTransform(0.1,27);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.502)").s().p("AkoJ5Qh6gVgBgeIAAhiQAAgIAJgIQALgIAWgIIi2vMQgSgIgBgIIAAgyIgBgCQAAgKAYgJQAngQBrgMQCrgTDuAAQDwAACqATQCpATABAbIAAA0QgBAJgRAIIi0PMQAWAIALAIQAJAHAAAIIAABlQgEAdh3AUQh8AWiwAAQitAAh8gWgAl0HiIABAFIgBgGIAAABg");
	this.shape_9.setTransform(0.5,81.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_9},{t:this.shape_5},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_3},{t:this.shape_4},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.2,21.1,104.5,118.1);


(lib.pot = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgsAtQgTgTAAgaQAAgZATgTQATgTAZAAQAaAAATATQATATAAAZQAAAagTATQgTATgaAAQgZAAgTgTg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-6.4,-6.4,12.9,12.9);


(lib.刷新 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABQBYQgJgEADgLQgIAFgHgFQgGgHAHgIQAKgMAFgOQAFgJAJAFQAIAGgDAJQgHAQgIAKQADgCAFACQANAEgBgGIAAgvIgdAAQgIgBgBgKQABgJAIAAIAdAAIAAgJIgdAAQgIgBgBgKQABgKAIgBIAPAAIgGgWIgFAAQgIAAAAgLQABgKAIgBIAbAAIAAgDIgBgCQgCgJALgCQALgBACAJIABAIIAYAAQAJAAAAAKQAAALgIABIgEAAIgDAMIgDAKIAKAAQAKABAAALQgBAJgKABIgbAAIAAAJIAcAAQAIAAABAIQgBAKgIABIgcAAIAAAyQAAAXgUAAQgJAAgMgEgABpgmIACAHIAKAAIAGgWIgWAAIAEAPgADIBPIAAhbIgPAAIAAASQgBAzgWAXQgJALgJgIQgHgJAJgLQgCAAgFgEIgHgHIgDgEQgGgJAFgGQAHgHAHAGIAOAPQAGgQAAgaIAAhAQgCgVAZACQAHAAAZgEIAPgCQAIABABAKQgBAJgIADQgVAEgWAAQgEABAAADIAAASIAyAAQAIABABAKQgBALgIABIgMAAIAABaQgBAKgKABQgLAAgBgKgAiyBNIAAhIIgHAAIgCADIAAA+QgBAIgJABQgKgBgBgIIAAhEQAAgQARAAIANAAIAAgOIgfAAQgBBCgLAgQgEAKgMgCQgJgEADgLQALghAAgxIAAgzQAAgSAPAAIBOAAQAQgBgBARIAAAdQACAQgRgBIgSAAIAAAOIAOAAQASgCAAAQIAAA/QAAAOgQAAQgNABgDgIIAAAHQAAAKgKABQgKgBgBgKgAidA7QABgDAEAAQAGAAAAgCIAAguQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAgBAAIgIAAgAjShAIAAAOIA+AAQABAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAgBIAAgLQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAgBAAIg7AAIgDACgAhoBSQgMgDgBgJQACgLALABIADABQAOAFgCgIIAAiGQABgLAKgBQAKABABAKIAACNQACAVgVAAQgIAAgKgDgAh2AiIAAhiQABgKAKgBQALAAAAAKIAABjQAAALgLAAQgKAAgBgLg");
	this.shape.setTransform(34,13.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2290B1").s().rr(-30.6,-12,61.2,24,4.4);
	this.shape_1.setTransform(34.5,13.5,1.126,1.126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,27.1);


// stage content:
(lib.donghua1 = function() {
	this.initialize();

	// 图层 1
	this.recycleBin = new lib.垃圾桶();
	this.recycleBin.setTransform(124.5,580.9);

	this.p7 = new lib.pot();
	this.p7.setTransform(315.3,473.1);

	this.p8 = new lib.pot();
	this.p8.setTransform(393.7,473.1);

	this.p9 = new lib.pot();
	this.p9.setTransform(460.3,473.1);

	this.p10 = new lib.pot();
	this.p10.setTransform(577.4,473.1);

	this.p11 = new lib.pot();
	this.p11.setTransform(735.1,473.1);

	this.p6 = new lib.pot();
	this.p6.setTransform(644.3,412.9);

	this.p5 = new lib.pot();
	this.p5.setTransform(535.6,412.9);

	this.p4 = new lib.pot();
	this.p4.setTransform(455.2,412.9);

	this.p3 = new lib.pot();
	this.p3.setTransform(409,412.9);

	this.p2 = new lib.pot();
	this.p2.setTransform(355,412.9);

	this.p1 = new lib.pot();
	this.p1.setTransform(442.3,279.6);

	this.undoBtn = new lib.撤销();
	this.undoBtn.setTransform(749.1,685.1,1.291,1.292);
	new cjs.ButtonHelper(this.undoBtn, 0, 1, 2, false, new lib.撤销(), 3);

	this.updateBtn = new lib.刷新();
	this.updateBtn.setTransform(890.1,685.1,1.291,1.292);
	new cjs.ButtonHelper(this.updateBtn, 0, 1, 2, false, new lib.刷新(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("ABnFtIGiJaIYqAAIuNpaABnFtIQ/AAArIFtIAxJaISgAAAyIFtIHAAAIMvAAAyIFtIiZJaIKKAAA6lFtIIdAAA6lFtImNJaIMRAAAs1vGIfbUzAs1vGIOcUzAs1vGItwUzAs1vGIlTUzAs1vGIBtUz");
	this.shape.setTransform(525.2,376.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#5F55D9").s().p("AIJPHImipaIsvAAIht0zIBtUzInAAAIFT0zIOcUzIuc0zIfbUzIw/AAIQ/AAIONJagAqXPHIgxpaIMvAAIGiJagA0hPHICZpaIHAAAIAxJagA0hPHIsRAAIGNpaIIdAAIodAAINw0zIlTUzIiZJag");
	this.shape_1.setTransform(525.2,376.3);

	this.addChild(this.shape_1,this.shape,this.updateBtn,this.undoBtn,this.p1,this.p2,this.p3,this.p4,this.p5,this.p6,this.p11,this.p10,this.p9,this.p8,this.p7,this.recycleBin);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(584.3,657.1,906.9,446.9);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;