

$("#demon_BtnA").click(function(){
	 $("#demon_BtnA span").toggleClass("arrowRight_cur");
	 console.log("aaaaaaaaa");
})

$("#demon_BtnB").click(function(){
	 $("#demon_BtnB span").toggleClass("arrowRight_cur");
	  console.log("bbbbbbbb");
})

$("#demon_BtnC").click(function(){
	 $("#demon_BtnC span").toggleClass("arrowRight_cur");
	  console.log("ccccccc");
})

$("#demon_BtnD").click(function(){
	 $("#demon_BtnD span").toggleClass("arrowRight_cur");
	  console.log("ddddddd");
})