(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 1024,
	height: 768,
	fps: 24,
	color: "#FFFFFF",
	manifest: []
};



// symbols:



(lib.涂2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhfBXQgJgEADgJQADgJAIACQAXAGgEgGIAAgxIgvAAQgIAAAAgLQABgIAHgBIAvAAIAAgSIgeAAQgNAAADgOQgDADgEABQgKADgFgJQgDgJAHgFQAhgTAQgMIABgCQAKgJAGAAQAGAAAKAIIAEACQASANAaAPQAJAHgHALQgFAIgJgIQADAPgKABIgeAAIAAASIAvAAQAOAJgOALIgvAAIAAAzQABAYgVAAQgLAAgQgGgAhTg1IgQALIBOAAIgTgLIgVgNQgDAAgTANgAioBYQgIgFAEgJQAMgbAJgcQACgHAJABQAJADAAAIQgGAWgPAnQgEAEgFAAIgHgBgAiCBQQgIgGAFgHIAYglQAFgIAKADQAJAFgDAIQgUAggHAIQgEADgFAAQgDAAgDgBgAgQBKQgFgGgIgOIgJgRQgEgIAKgGQAKgDAGAJQAMASAHATQAEAJgHAFIgFAAQgGAAgFgGgABdBHQgPAAAAgNQgBgEAFgGIANgOQAZgcAMgQQAHgJAAgJQgBgOgNgCQgMAAgGASQgFAPgIgBQgPAAAAgOQAEgoArgFQAqADACAmQAAAWgjAmIgMAPIAkAAQAOAAABANQgBANgNAAgAiTAAQgOgKgIgKQgEgSATAEIAWAVQAEANgOAAIgFAAgAiNg0QgFgDgGgHIgLgKQgEgUAUAFIAWAUQAEAGgHAHQgFAEgEAAQgCAAgCgCg");
	this.shape.setTransform(33.9,12.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2290B1").s().rr(-30.6,-12,61.2,24,4.4);
	this.shape_1.setTransform(34.5,13.5,1.126,1.126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,27.1);


(lib.涂1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhIBXQgJgEADgJQADgJAIACQAXAGgEgGIAAgxIgvAAQgIAAAAgLQABgIAHgBIAvAAIAAgSIgeAAQgNAAADgOQgDADgEABQgKADgFgJQgDgJAHgFQAhgTAQgMIABgCQAKgJAGAAQAGAAAKAIIAEACQASANAaAPQAJAHgHALQgHAIgJgIQADAPgKABIgcAAIAAASIAtAAQAQAJgQALIgtAAIAAAzQABAYgVAAQgLAAgQgGgAg8g1IgQALIBMAAIgRgLIgVgNQgDAAgTANgAiRBYQgIgFAEgJQAMgbAJgcQACgHAJABQAJADAAAIQgGAWgPAnQgEAEgFAAIgHgBgAhrBQQgIgGAFgHIAYglQAFgIAKADQAJAFgDAIQgUAggHAIQgEADgFAAQgDAAgDgBgAAFBKQgFgGgGgOIgJgRQgEgIAKgGQAJgDAFAJQAMASAJATQAEAJgJAFIgFAAQgHAAgEgGgAB6A5IAAhjIgLAAQgOAAgBgOQABgLAOgCIAcAAQAMABABANIAABwQgBAOgOAAQgPAAAAgOgAh8AAQgOgKgIgKQgEgSATAEIAWAVQAEANgOAAIgFAAgAh2g0QgFgDgGgHIgLgKQgEgUAUAFIAWAUQAEAGgHAHQgFAEgEAAQgCAAgCgCg");
	this.shape.setTransform(33.7,13);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2290B1").s().rr(-30.6,-12,61.2,24,4.4);
	this.shape_1.setTransform(34.5,13.5,1.126,1.126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,27.1);


(lib.全涂 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABZBXQgJgEADgJQADgJAIACQAXAGgEgGIAAgxIgvAAQgIAAAAgLQABgIAHgBIAvAAIAAgSIgeAAQgNAAADgOQgDADgEABQgKADgFgJQgDgJAHgFQAhgTAQgMIABgCQAKgJAGAAQAGAAAKAIIAEACQASANAcAPQAJAHgHALQgHAIgJgIQADAPgKABIgeAAIAAASIAvAAQAQAJgQALIgvAAIAAAzQABAYgVAAQgLAAgQgGgABlg1IgQALIBOAAIgTgLIgVgNQgDAAgTANgAAQBYQgIgFAEgJQAMgbAJgcQACgHAJABQAJADAAAIQgGAWgPAnQgEAEgGAAIgGgBgAivBVQgKgBgBgKQABgJAKgBIBBAAIAAgaIgyAAQgQgLAQgLIAyAAIAAgWIgoAAQgMAAABgOIgCACIgIAEQgPAGgDgJQgFgLALgHQAogVAegbQAJgIAFACQAGAAALAIIACAAQAhAYAlAWQAKAHgEALQgHAIgLgEQgHgEgHgGQABAFgBAFQgBAHgKAAIgnAAIAAAWIAyAAQAIABABAKQgBALgIAAIgyAAIAAAaIBCAAQAIABABAJQgBAKgIABgAhqg7IgCACQgRAPgXAOIBkAAQAEAAAEACQgXgOgXgSIgLgGQgDAAgGAFgAA2BQQgIgGAFgHIAYglQAFgIAKADQAJAFgDAIQgUAggHAIQgEADgFAAQgDAAgDgBgACoBKQgFgGgIgOIgJgRQgEgIAKgGQAKgDAGAJQAMASAJATQAEAJgJAFIgFAAQgHAAgEgGgAAlAAQgOgKgIgKQgEgSATAEIAWAVQAEANgOAAIgFAAgAArg0QgFgDgGgHIgLgKQgEgUAUAFIAWAUQAEAGgHAHQgFAEgEAAQgCAAgCgCg");
	this.shape.setTransform(34.5,13.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2290B1").s().rr(-30.6,-12,61.2,24,4.4);
	this.shape_1.setTransform(34.5,13.5,1.126,1.126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,27.1);


(lib.bg = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AiDiDIEHAAIAAEHIkHAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F3F3").s().p("AiDCEIAAkHIEHAAIAAEHg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.2,-14.2,28.5,28.5);


(lib.刷新 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABQBYQgJgEADgLQgIAFgHgFQgGgHAHgIQAKgMAFgOQAFgJAJAFQAIAGgDAJQgHAQgIAKQADgCAFACQANAEgBgGIAAgvIgdAAQgIgBgBgKQABgJAIAAIAdAAIAAgJIgdAAQgIgBgBgKQABgKAIgBIAPAAIgGgWIgFAAQgIAAAAgLQABgKAIgBIAbAAIAAgDIgBgCQgCgJALgCQALgBACAJIABAIIAYAAQAJAAAAAKQAAALgIABIgEAAIgDAMIgDAKIAKAAQAKABAAALQgBAJgKABIgbAAIAAAJIAcAAQAIAAABAIQgBAKgIABIgcAAIAAAyQAAAXgUAAQgJAAgMgEgABpgmIACAHIAKAAIAGgWIgWAAIAEAPgADIBPIAAhbIgPAAIAAASQgBAzgWAXQgJALgJgIQgHgJAJgLQgCAAgFgEIgHgHIgDgEQgGgJAFgGQAHgHAHAGIAOAPQAGgQAAgaIAAhAQgCgVAZACQAHAAAZgEIAPgCQAIABABAKQgBAJgIADQgVAEgWAAQgEABAAADIAAASIAyAAQAIABABAKQgBALgIABIgMAAIAABaQgBAKgKABQgLAAgBgKgAiyBNIAAhIIgHAAIgCADIAAA+QgBAIgJABQgKgBgBgIIAAhEQAAgQARAAIANAAIAAgOIgfAAQgBBCgLAgQgEAKgMgCQgJgEADgLQALghAAgxIAAgzQAAgSAPAAIBOAAQAQgBgBARIAAAdQACAQgRgBIgSAAIAAAOIAOAAQASgCAAAQIAAA/QAAAOgQAAQgNABgDgIIAAAHQAAAKgKABQgKgBgBgKgAidA7QABgDAEAAQAGAAAAgCIAAguQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAgBAAIgIAAgAjShAIAAAOIA+AAQABAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAgBIAAgLQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAgBAAIg7AAIgDACgAhoBSQgMgDgBgJQACgLALABIADABQAOAFgCgIIAAiGQABgLAKgBQAKABABAKIAACNQACAVgVAAQgIAAgKgDgAh2AiIAAhiQABgKAKgBQALAAAAAKIAABjQAAALgLAAQgKAAgBgLg");
	this.shape.setTransform(34,13.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2290B1").s().rr(-30.6,-12,61.2,24,4.4);
	this.shape_1.setTransform(34.5,13.5,1.126,1.126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,27.1);


(lib.mc = function() {
	this.initialize();

	// 图层 2
	this.txt = new cjs.Text("10", "27px 'FZCuYuan-M03'");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 29;
	this.txt.lineWidth = 26;
	this.txt.setTransform(-1.5,-12.8);

	// 图层 1
	this.bg = new lib.bg();
	this.bg.setTransform(0,0,1.132,1.132);

	this.addChild(this.bg,this.txt);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-15.5,-15.5,31.1,37);


// stage content:
(lib.donghua = function() {
	this.initialize();

	// 图层 3
	this.updateBtn = new lib.刷新();
	this.updateBtn.setTransform(594.8,718.3,1.015,1.015);
	new cjs.ButtonHelper(this.updateBtn, 0, 1, 2, false, new lib.刷新(), 3);

	this.allBtn = new lib.全涂();
	this.allBtn.setTransform(493.1,718.3,1.015,1.015);
	new cjs.ButtonHelper(this.allBtn, 0, 1, 2, false, new lib.全涂(), 3);

	this.tuBtn2 = new lib.涂2();
	this.tuBtn2.setTransform(391.5,718.3,1.015,1.015);
	new cjs.ButtonHelper(this.tuBtn2, 0, 1, 2, false, new lib.涂2(), 3);

	this.tuBtn1 = new lib.涂1();
	this.tuBtn1.setTransform(289.8,718.3,1.015,1.013);
	new cjs.ButtonHelper(this.tuBtn1, 0, 1, 2, false, new lib.涂1(), 3);

	this.addChild(this.tuBtn1,this.tuBtn2,this.allBtn,this.updateBtn);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(801.8,1102.3,375,27.5);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;